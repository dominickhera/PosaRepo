#ifndef __DHERA__RUN__
#define __DHERA__RUN__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "carbon.h"
#include "ackermann.h"
#include "newton.h"
#include <math.h>

#endif