#ifndef __DHERA__ACKERMANN__
#define __DHERA__ACKERMANN__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

void ackermannInit();
int ackermanns(int x, int y);

#endif