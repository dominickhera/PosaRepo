#ifndef __DHERA__CARBON__
#define __DHERA__CARBON__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

void carbonInit ();
void swaparoni(char *x, char *y);
void switcharoni(char *c, int x, int y);

#endif